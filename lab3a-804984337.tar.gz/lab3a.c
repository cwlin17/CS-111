// NAME: Carol Lin
// EMAIL: carol9gmail@yahoo.com
// ID: 804984337

#include <stdlib.h>
#include <stdio.h>
#include "ext2_fs.h"

const int SUPER_BLOCK_OFFSET = 1024;

struct ext2_super_block superBlock;

int main(int argc, char* argv[]){
  if(argc != 2){
    fprintf(stderr, "Wrong number of arguments.\n");
    exit(1);
  }

  int fd = open(argv[1], O_RDONLY);
  if(fd == -1){
    fprintf(stderr, "Error opening file.\n");
    exit(2);
  }

  

  exit(0);
}
